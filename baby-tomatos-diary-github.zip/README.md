# 🍅 Baby Tomato's Diary

A cosy, installable writing space for projects and chapters. Plain HTML, CSS and JavaScript, with no build step.

## Features
- Project library with search, favourites, sorting and cover colours
- Chapters inside each project
- Writing editor with live word count and autosave
- JSON backup export and import
- Installable PWA with offline loading after the first visit

## Your data
Writing is stored in your browser's local storage on the device you use. Nothing is sent to a server and nothing syncs between devices. Use **Export** regularly and keep the backup file somewhere safe. Don't clear site data without exporting first.

## Publish with GitHub Pages
1. Create a new repository on GitHub, for example `baby-tomatos-diary`.
2. Upload **the contents** of this folder so that `index.html` sits at the top level of the repo, not inside a subfolder. Include the hidden `.nojekyll` file.
3. Go to **Settings → Pages**. Under *Build and deployment*, set Source to **Deploy from a branch**, choose `main` and `/ (root)`, then Save.
4. After a minute or two the site is live at `https://YOUR-USERNAME.github.io/baby-tomatos-diary/`.
5. Open that link in Chrome on your phone, then use ⋮ → **Add to Home screen** / **Install app**.

## Fonts
Handlee and Nunito load from Google Fonts. A rounded system-font fallback is used if they can't load.
