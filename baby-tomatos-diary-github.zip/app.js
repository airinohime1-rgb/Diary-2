(() => {
  'use strict';

  const STORAGE_KEY = 'baby-tomatos-diary-v1';
  const covers = ['rose', 'lavender', 'sage', 'butter', 'sky', 'berry'];
  const coverSymbols = { rose: '✿', lavender: '✧', sage: '❀', butter: '☼', sky: '✦', berry: '♡' };
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const escapeHTML = (value = '') => String(value).replace(/[&<>"']/g, ch => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[ch]));
  const makeId = () => (crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`);
  const now = () => new Date().toISOString();

  let state = { projects: [], activeProjectId: null, activeChapterId: null, filter: 'all', query: '', sortNewest: true, selectedCover: 'rose' };
  let editingProjectId = null;
  let pendingDelete = null;
  let saveTimer = null;
  let toastTimer = null;

  const load = () => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const saved = JSON.parse(raw);
      if (saved && Array.isArray(saved.projects)) state.projects = saved.projects.map(normaliseProject);
    } catch (error) {
      console.warn('Could not load the diary data:', error);
      showToast('I could not read the saved diary data.');
    }
  };
  const normaliseProject = p => ({
    id: String(p.id || makeId()), title: String(p.title || 'Untitled project'), description: String(p.description || ''),
    cover: covers.includes(p.cover) ? p.cover : 'rose', favourite: Boolean(p.favourite), createdAt: p.createdAt || now(), updatedAt: p.updatedAt || now(),
    chapters: Array.isArray(p.chapters) ? p.chapters.map((c, i) => ({ id: String(c.id || makeId()), title: String(c.title || `Chapter ${i + 1}`), body: String(c.body || ''), favourite: Boolean(c.favourite), updatedAt: c.updatedAt || now() })) : []
  });
  const persist = () => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify({ projects: state.projects })); }
    catch (error) { console.error(error); showToast('Storage is full. Export a backup before adding more.'); }
  };
  const schedulePersist = () => {
    clearTimeout(saveTimer);
    $('#saveStatus').textContent = 'Saving…';
    saveTimer = setTimeout(() => { persist(); const status = $('#saveStatus'); if (status) status.textContent = 'Saved on this device'; }, 280);
  };
  const showToast = message => {
    const el = $('#toast'); el.textContent = message; el.classList.add('show');
    clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 2300);
  };
  const activeProject = () => state.projects.find(p => p.id === state.activeProjectId) || null;
  const activeChapter = () => { const p = activeProject(); return p?.chapters.find(c => c.id === state.activeChapterId) || null; };
  const wordCount = text => (text.trim().match(/\S+/g) || []).length;
  const shortDate = value => { try { return new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric' }).format(new Date(value)); } catch { return ''; } };
  const projectWords = p => p.chapters.reduce((sum, c) => sum + wordCount(c.body), 0);
  const matchingProjects = () => {
    const q = state.query.trim().toLowerCase();
    return state.projects.filter(p => (state.filter !== 'favorites' || p.favourite) && (!q || p.title.toLowerCase().includes(q) || p.description.toLowerCase().includes(q) || p.chapters.some(c => c.title.toLowerCase().includes(q) || c.body.toLowerCase().includes(q))));
  };

  function renderProjects() {
    const list = $('#projectList');
    const projects = matchingProjects().sort((a, b) => state.sortNewest ? new Date(b.updatedAt) - new Date(a.updatedAt) : a.title.localeCompare(b.title));
    $('#projectCount').textContent = `${projects.length} ${projects.length === 1 ? 'PROJECT' : 'PROJECTS'}`;
    if (!projects.length) {
      list.innerHTML = `<div class="empty-projects"><strong>${state.query ? 'Nothing found just yet' : state.filter === 'favorites' ? 'No favourites yet' : 'Your library is waiting'}</strong>${state.query ? 'Try a different title or keyword.' : state.filter === 'favorites' ? 'Tap the little heart on a project to keep it here.' : 'Create a project and give your ideas a home.'}</div>`;
      return;
    }
    list.innerHTML = projects.map(p => `
      <div class="project-card ${p.id === state.activeProjectId ? 'selected' : ''}" data-project="${escapeHTML(p.id)}" role="button" tabindex="0" aria-label="Open ${escapeHTML(p.title)}">
        <div class="cover-mini cover-${p.cover}">${coverSymbols[p.cover]}</div>
        <div class="project-card-copy"><p class="project-card-title">${escapeHTML(p.title)}</p><p class="project-card-meta">${p.chapters.length} ${p.chapters.length === 1 ? 'chapter' : 'chapters'} · ${shortDate(p.updatedAt)}</p></div>
        ${p.favourite ? '<span class="project-card-star" aria-label="Favourite">♥</span>' : ''}
      </div>`).join('');
    $$('.project-card', list).forEach(card => {
      const open = () => openProject(card.dataset.project);
      card.addEventListener('click', open);
      card.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } });
    });
  }

  function renderWorkspace() {
    const shell = $('#appShell');
    const project = activeProject();
    const welcome = $('#welcomeScreen');
    const workspace = $('#projectWorkspace');
    if (!project) {
      shell.classList.remove('has-project');
      welcome.classList.remove('hidden'); workspace.classList.add('hidden');
      return;
    }
    shell.classList.add('has-project');
    welcome.classList.add('hidden'); workspace.classList.remove('hidden');
    const chapter = activeChapter();
    workspace.className = `project-workspace ${chapter ? 'mobile-editor' : 'mobile-chapters'}`;
    const chapterItems = project.chapters.map((c, i) => `
      <div class="chapter-item ${c.id === state.activeChapterId ? 'active' : ''}" data-chapter="${escapeHTML(c.id)}" role="button" tabindex="0" aria-label="Open ${escapeHTML(c.title)}">
        <span class="chapter-number">${String(i + 1).padStart(2,'0')}</span><span class="chapter-item-title">${escapeHTML(c.title)}</span><span class="chapter-item-count">${wordCount(c.body)}w</span>
      </div>`).join('');
    const chapterPane = `
      <aside class="chapter-pane">
        <div class="project-topline"><button class="back-link" id="backToProjects">← Library</button><span class="crumb-dot">/</span><span class="eyebrow" style="margin:0">PROJECT</span></div>
        <div class="project-cover-large cover-${project.cover}"><h2>${escapeHTML(project.title)}</h2></div>
        ${project.description ? `<p class="project-description">${escapeHTML(project.description)}</p>` : ''}
        <div class="chapter-heading"><h3>CHAPTERS · ${project.chapters.length}</h3><button class="small-plus" id="addChapter" aria-label="Add chapter">＋</button></div>
        <div class="chapter-list">${chapterItems || '<div class="chapter-empty">Your first chapter is just a little<br>＋ away. Start whenever you are ready.</div>'}</div>
        <div class="project-actions"><button id="editProject">Edit project</button><button id="toggleProjectFavourite">${project.favourite ? '♥ Favourited' : '♡ Favourite'}</button><button id="deleteProject">Delete</button></div>
        <div class="chapter-pane-foot">${project.chapters.length} chapters · ${projectWords(project)} words in this project</div>
      </aside>`;
    const editorPane = chapter ? `
      <section class="writing-pane">
        <div class="editor-toolbar">
          <button class="mobile-back" id="backToChapters">← Chapters</button>
          <div class="editor-breadcrumb">${escapeHTML(project.title)} <span>/</span> ${escapeHTML(chapter.title)}</div>
          <div class="toolbar-actions">
            <button class="icon-button ${chapter.favourite ? 'is-favourite' : ''}" id="toggleChapterFavourite" title="Favourite chapter" aria-label="Favourite chapter">${chapter.favourite ? '♥' : '♡'}</button>
            <div class="more-menu"><button class="icon-button" id="chapterMenuButton" aria-label="Chapter options">···</button><div class="menu-popover" id="chapterMenu"><button id="renameChapter">Rename chapter</button><button id="deleteChapter">Delete chapter</button></div></div>
          </div>
        </div>
        <div class="editor-paper">
          <div class="chapter-kicker">A PAGE FROM YOUR STORY</div>
          <input class="chapter-title-input" id="chapterTitleEditor" maxlength="90" value="${escapeHTML(chapter.title)}" aria-label="Chapter title" placeholder="Give this chapter a title…">
          <div class="editor-divider"></div>
          <textarea class="chapter-body" id="chapterBody" spellcheck="true" placeholder="Let your thoughts find their way onto the page…">${escapeHTML(chapter.body)}</textarea>
          <div class="editor-footer"><span id="wordCount">${wordCount(chapter.body)} words</span><span class="save-status"><i class="save-dot"></i><span id="saveStatus">Saved on this device</span></span></div>
        </div>
      </section>` : `
      <section class="writing-pane chapter-placeholder">
        <div class="editor-toolbar"><div class="editor-breadcrumb">${escapeHTML(project.title)}</div><div class="toolbar-actions"><button class="icon-button" id="addChapterTop" title="Add chapter">＋</button></div></div>
        <div class="welcome-screen"><div class="welcome-art" aria-hidden="true"><div class="sun-shape"></div><div class="book-shape"><span>✧</span></div><div class="spark spark-one">✿</div><div class="spark spark-two">✦</div></div><p class="eyebrow">YOUR STORY, YOUR PACE</p><h2>${project.chapters.length ? 'Choose a chapter<br>to keep writing.' : 'A brand new page.'}</h2><p class="welcome-copy">${project.chapters.length ? 'Pick a chapter from the list, or create another one.' : 'Give your first chapter a name. It does not have to be perfect; it only has to begin.'}</p><button class="primary-button" id="addChapterWelcome">＋ Add a chapter</button></div>
      </section>`;
    workspace.innerHTML = chapterPane + editorPane;
    $('#backToProjects')?.addEventListener('click', () => { state.activeProjectId = null; state.activeChapterId = null; renderAll(); });
    $('#addChapter')?.addEventListener('click', openChapterDialog);
    $('#addChapterTop')?.addEventListener('click', openChapterDialog);
    $('#addChapterWelcome')?.addEventListener('click', openChapterDialog);
    $('#editProject')?.addEventListener('click', () => openProjectDialog(project));
    $('#toggleProjectFavourite')?.addEventListener('click', () => { project.favourite = !project.favourite; project.updatedAt = now(); persist(); renderAll(); showToast(project.favourite ? 'Added to your favourites ♥' : 'Removed from favourites'); });
    $('#deleteProject')?.addEventListener('click', () => askDelete('project', project.id));
    $$('.chapter-item', workspace).forEach(item => {
      const open = () => { state.activeChapterId = item.dataset.chapter; renderWorkspace(); renderProjects(); };
      item.addEventListener('click', open);
      item.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } });
    });
    if (chapter) bindEditor(project, chapter);
  }

  function bindEditor(project, chapter) {
    $('#backToChapters')?.addEventListener('click', () => { state.activeChapterId = null; renderWorkspace(); renderProjects(); });
    const title = $('#chapterTitleEditor');
    const body = $('#chapterBody');
    const count = $('#wordCount');
    const saveStatus = $('#saveStatus');
    const updateChapter = () => {
      chapter.title = title.value.trim() || 'Untitled chapter';
      chapter.body = body.value;
      chapter.updatedAt = now(); project.updatedAt = now();
      count.textContent = `${wordCount(body.value)} words`;
      const crumb = $('.editor-breadcrumb'); if (crumb) crumb.innerHTML = `${escapeHTML(project.title)} <span>/</span> ${escapeHTML(chapter.title)}`;
      renderProjects();
      // Keep the selected title in the chapter list up to date without disturbing the editor.
      const item = $(`.chapter-item[data-chapter="${CSS.escape(chapter.id)}"]`);
      if (item) { $('.chapter-item-title', item).textContent = chapter.title; $('.chapter-item-count', item).textContent = `${wordCount(body.value)}w`; }
      schedulePersist();
    };
    title.addEventListener('input', updateChapter);
    body.addEventListener('input', updateChapter);
    $('#toggleChapterFavourite')?.addEventListener('click', () => { chapter.favourite = !chapter.favourite; persist(); const btn = $('#toggleChapterFavourite'); btn.textContent = chapter.favourite ? '♥' : '♡'; btn.classList.toggle('is-favourite', chapter.favourite); showToast(chapter.favourite ? 'Chapter saved to favourites ♥' : 'Chapter unfavourited'); });
    $('#chapterMenuButton')?.addEventListener('click', () => $('#chapterMenu').classList.toggle('open'));
    $('#renameChapter')?.addEventListener('click', () => { $('#chapterMenu').classList.remove('open'); title.focus(); title.select(); showToast('Edit the chapter title at the top of the page.'); });
    $('#deleteChapter')?.addEventListener('click', () => { $('#chapterMenu').classList.remove('open'); askDelete('chapter', chapter.id); });
  }

  function renderAll() { renderProjects(); renderWorkspace(); }
  function openProject(id) { state.activeProjectId = id; state.activeChapterId = null; renderAll(); }

  function openProjectDialog(project = null) {
    editingProjectId = project?.id || null;
    state.selectedCover = project?.cover || 'rose';
    $('#projectDialogTitle').textContent = project ? 'Edit your project' : 'Create a project';
    $('#saveProjectButton').textContent = project ? 'Save changes' : 'Create project';
    $('#projectTitle').value = project?.title || '';
    $('#projectDescription').value = project?.description || '';
    $$('.cover-choice').forEach(b => b.classList.toggle('selected', b.dataset.cover === state.selectedCover));
    $('#projectDialog').showModal();
    setTimeout(() => $('#projectTitle').focus(), 50);
  }
  function saveProject(event) {
    event.preventDefault();
    const title = $('#projectTitle').value.trim();
    if (!title) { $('#projectTitle').focus(); return; }
    if (editingProjectId) {
      const p = state.projects.find(x => x.id === editingProjectId);
      if (p) { p.title = title; p.description = $('#projectDescription').value.trim(); p.cover = state.selectedCover; p.updatedAt = now(); }
      showToast('Project details updated ✿');
    } else {
      const project = { id: makeId(), title, description: $('#projectDescription').value.trim(), cover: state.selectedCover, favourite: false, createdAt: now(), updatedAt: now(), chapters: [] };
      state.projects.unshift(project); state.activeProjectId = project.id; state.activeChapterId = null;
      showToast('Your new project is ready ✿');
    }
    persist(); $('#projectDialog').close(); renderAll();
  }
  function openChapterDialog() {
    $('#chapterTitle').value = `Chapter ${((activeProject()?.chapters.length || 0) + 1)}`;
    $('#chapterDialog').showModal(); setTimeout(() => { $('#chapterTitle').focus(); $('#chapterTitle').select(); }, 50);
  }
  function saveChapter(event) {
    event.preventDefault();
    const p = activeProject(); const title = $('#chapterTitle').value.trim();
    if (!p || !title) return;
    const chapter = { id: makeId(), title, body: '', favourite: false, updatedAt: now() };
    p.chapters.push(chapter); p.updatedAt = now(); state.activeChapterId = chapter.id;
    persist(); $('#chapterDialog').close(); renderAll(); showToast('A fresh page, just for you.');
  }
  function askDelete(type, id) {
    pendingDelete = { type, id };
    const isProject = type === 'project';
    const thing = isProject ? state.projects.find(p => p.id === id)?.title : activeProject()?.chapters.find(c => c.id === id)?.title;
    $('#confirmTitle').textContent = `Delete ${isProject ? 'this project' : 'this chapter'}?`;
    $('#confirmCopy').textContent = isProject ? `“${thing || 'Untitled project'}” and all its chapters will be removed from this device. Export a backup first if you want to keep a copy.` : `“${thing || 'Untitled chapter'}” will be removed from this project.`;
    $('#confirmDialog').showModal();
  }
  function confirmDelete(event) {
    event.preventDefault(); if (!pendingDelete) return;
    if (pendingDelete.type === 'project') {
      state.projects = state.projects.filter(p => p.id !== pendingDelete.id);
      state.activeProjectId = null; state.activeChapterId = null; showToast('Project deleted.');
    } else {
      const p = activeProject(); if (p) p.chapters = p.chapters.filter(c => c.id !== pendingDelete.id);
      state.activeChapterId = null; if (p) p.updatedAt = now(); showToast('Chapter deleted.');
    }
    pendingDelete = null; persist(); $('#confirmDialog').close(); renderAll();
  }

  function exportBackup() {
    const payload = { app: "Baby Tomato's Diary", version: 1, exportedAt: now(), projects: state.projects };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `baby-tomatos-diary-backup-${new Date().toISOString().slice(0,10)}.json`; a.click(); URL.revokeObjectURL(url);
    showToast('Your diary backup has been exported.');
  }
  function importBackup(file) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        if (!data || !Array.isArray(data.projects)) throw new Error('This file does not look like a diary backup.');
        const imported = data.projects.map(normaliseProject);
        const replace = confirm(`Import ${imported.length} project(s)? Choose OK to replace the diary currently on this device, or Cancel to merge them.`);
        if (replace) state.projects = imported;
        else {
          const ids = new Set(state.projects.map(p => p.id));
          imported.forEach(p => { if (ids.has(p.id)) p.id = makeId(); state.projects.push(p); });
        }
        state.activeProjectId = null; state.activeChapterId = null; persist(); renderAll(); showToast('Diary backup imported successfully.');
      } catch (error) { alert(error.message || 'Could not import that file.'); }
      $('#importFile').value = '';
    };
    reader.onerror = () => { alert('I could not read that file.'); $('#importFile').value = ''; };
    reader.readAsText(file);
  }

  // App events
  $('#newProjectButton').addEventListener('click', () => openProjectDialog());
  $('#mobileNewProject').addEventListener('click', () => openProjectDialog());
  $('#welcomeCreate').addEventListener('click', () => openProjectDialog());
  $('#projectForm').addEventListener('submit', saveProject);
  $('#chapterForm').addEventListener('submit', saveChapter);
  $('#confirmDeleteButton').addEventListener('click', confirmDelete);
  $('#coverChoices').addEventListener('click', e => { const b = e.target.closest('.cover-choice'); if (!b) return; state.selectedCover = b.dataset.cover; $$('.cover-choice').forEach(x => x.classList.toggle('selected', x === b)); });
  $('#searchInput').addEventListener('input', e => { state.query = e.target.value; renderProjects(); });
  $('#sortButton').addEventListener('click', () => { state.sortNewest = !state.sortNewest; $('#sortButton').textContent = state.sortNewest ? 'Recently edited ↕' : 'Name A–Z ↕'; renderProjects(); });
  $$('.rail-button[data-filter]').forEach(btn => btn.addEventListener('click', () => {
    state.filter = btn.dataset.filter; $$('.rail-button[data-filter]').forEach(b => b.classList.toggle('active', b === btn));
    if (state.filter === 'favorites' && activeProject() && !activeProject().favourite) { state.activeProjectId = null; state.activeChapterId = null; }
    renderAll();
    if (window.innerWidth <= 720) { $('#appShell').classList.remove('has-project'); }
  }));
  $('#exportButton').addEventListener('click', exportBackup);
  $('#importButton').addEventListener('click', () => $('#importFile').click());
  $('#importFile').addEventListener('change', e => importBackup(e.target.files?.[0]));
  document.addEventListener('keydown', e => {
    if (e.key === '/' && !['INPUT','TEXTAREA'].includes(document.activeElement.tagName) && !e.ctrlKey && !e.metaKey) { e.preventDefault(); $('#searchInput').focus(); }
    if (e.key === 'Escape') $$('.menu-popover.open').forEach(m => m.classList.remove('open'));
  });
  document.addEventListener('click', e => { if (!e.target.closest('.more-menu')) $$('.menu-popover.open').forEach(m => m.classList.remove('open')); });
  window.addEventListener('beforeunload', () => { clearTimeout(saveTimer); persist(); });

  load(); renderAll();
  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
    window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(err => console.warn('Offline support could not be enabled:', err)));
  }
})();
